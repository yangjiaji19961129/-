package com.fengwuj.entity;

import java.sql.Timestamp;

public class Djczjl {
	
	private int id;
	private String czry;
	private String dw;
	private String tn;
	private String cz;
	private String spyj;
	private Timestamp czsj;
	private String bzly;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCzry() {
		return czry;
	}
	public void setCzry(String czry) {
		this.czry = czry;
	}
	public String getDw() {
		return dw;
	}
	public void setDw(String dw) {
		this.dw = dw;
	}
	public String getTn() {
		return tn;
	}
	public void setTn(String tn) {
		this.tn = tn;
	}
	public String getCz() {
		return cz;
	}
	public void setCz(String cz) {
		this.cz = cz;
	}
	public String getSpyj() {
		return spyj;
	}
	public void setSpyj(String spyj) {
		this.spyj = spyj;
	}
	public Timestamp getCzsj() {
		return czsj;
	}
	public void setCzsj(Timestamp czsj) {
		this.czsj = czsj;
	}
	public String getBzly() {
		return bzly;
	}
	public void setBzly(String bzly) {
		this.bzly = bzly;
	}

}
