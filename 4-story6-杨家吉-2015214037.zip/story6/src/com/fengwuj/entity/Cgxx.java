package com.fengwuj.entity;

import java.sql.Timestamp;
import java.util.Date;

public class Cgxx {
	
	private int id;
	private Timestamp bjjzrq;
	private String tn;
	private String sqdw;
	private String sqr;
	private String qfr;
	private Date sqrq;
	private Date starttime;
	private Date finishtime;
	private String mz;
	private double cgsl;
	private String ysfs;
	private String jhdd;
	private String jsfs;
	private String yunshufs;
	private String zgxj;
	private String zdxj;
	private String jsfkfs;
	private String bzjyq;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Timestamp getBjjzrq() {
		return bjjzrq;
	}
	public void setBjjzrq(Timestamp bjjzrq) {
		this.bjjzrq = bjjzrq;
	}
	public String getTn() {
		return tn;
	}
	public void setTn(String tn) {
		this.tn = tn;
	}
	public String getSqdw() {
		return sqdw;
	}
	public void setSqdw(String sqdw) {
		this.sqdw = sqdw;
	}
	public String getSqr() {
		return sqr;
	}
	public void setSqr(String sqr) {
		this.sqr = sqr;
	}
	public String getQfr() {
		return qfr;
	}
	public void setQfr(String qfr) {
		this.qfr = qfr;
	}
	public Date getSqrq() {
		return sqrq;
	}
	public void setSqrq(Date sqrq) {
		this.sqrq = sqrq;
	}
	public Date getStarttime() {
		return starttime;
	}
	public void setStarttime(Date starttime) {
		this.starttime = starttime;
	}
	public Date getFinishtime() {
		return finishtime;
	}
	public void setFinishtime(Date finishtime) {
		this.finishtime = finishtime;
	}
	public String getMz() {
		return mz;
	}
	public void setMz(String mz) {
		this.mz = mz;
	}
	public double getCgsl() {
		return cgsl;
	}
	public void setCgsl(double cgsl) {
		this.cgsl = cgsl;
	}
	public String getYsfs() {
		return ysfs;
	}
	public void setYsfs(String ysfs) {
		this.ysfs = ysfs;
	}
	public String getJhdd() {
		return jhdd;
	}
	public void setJhdd(String jhdd) {
		this.jhdd = jhdd;
	}
	public String getJsfs() {
		return jsfs;
	}
	public void setJsfs(String jsfs) {
		this.jsfs = jsfs;
	}
	public String getYunshufs() {
		return yunshufs;
	}
	public void setYunshufs(String yunshufs) {
		this.yunshufs = yunshufs;
	}
	public String getZgxj() {
		return zgxj;
	}
	public void setZgxj(String zgxj) {
		this.zgxj = zgxj;
	}
	public String getZdxj() {
		return zdxj;
	}
	public void setZdxj(String zdxj) {
		this.zdxj = zdxj;
	}
	public String getJsfkfs() {
		return jsfkfs;
	}
	public void setJsfkfs(String jsfkfs) {
		this.jsfkfs = jsfkfs;
	}
	public String getBzjyq() {
		return bzjyq;
	}
	public void setBzjyq(String bzjyq) {
		this.bzjyq = bzjyq;
	}
	
}
