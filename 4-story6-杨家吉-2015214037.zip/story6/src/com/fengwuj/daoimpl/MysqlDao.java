package com.fengwuj.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.util.List;

import javax.enterprise.inject.New;

import com.fengwuj.Dao.*;
import com.fengwuj.entity.User;
import com.fengwuj.util.DBConnection;
import com.mysql.cj.xdevapi.SqlDataResult;

public class MysqlDao implements Dao{
	
	@Override
	public User selectUser(String name) {
		String sql = "select * from user where username = ?";
		User user = new User();
		Connection conn = null;
		try {
			conn = DBConnection.getConnection();
			PreparedStatement psmt = conn.prepareStatement(sql);
			psmt.setString(1, name);
			ResultSet rs = psmt.executeQuery();
			if (rs.next()) {
				user.setId(rs.getInt("id"));
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setXm(rs.getString("xm"));
				user.setDw(rs.getString("dw"));
				user.setBm(rs.getString("bm"));
				user.setDh(rs.getString("dh"));
				user.setJs(rs.getString("js"));
			}
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}
}
