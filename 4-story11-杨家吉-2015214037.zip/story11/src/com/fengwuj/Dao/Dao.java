package com.fengwuj.Dao;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import com.fengwuj.entity.Cgsq;
import com.fengwuj.entity.User;

public interface Dao {
	
	public User selectUser(String name);

	public int updateUser(User user);
	
	public int deleteUser(String username);
	
	public int updateUserPassword(String username,String newpassword);
	
	public ArrayList<Cgsq> selectCgxqList(int status,int startRow);
	
	public ArrayList<Cgsq> selectCgxqListByTn(String tn);
	
	public ArrayList<Cgsq> selectCgxqListByDcmc(String dcmc,int startRow);
	
	public ArrayList<Cgsq> selectCgxqListByTandD(String tn,String dcmc);
	
	public int selectCgxqPage(int status);
	
	public int selectCgxqPage(String dcmc);
	
}
