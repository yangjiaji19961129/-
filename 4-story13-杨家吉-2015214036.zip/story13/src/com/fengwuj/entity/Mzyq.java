package com.fengwuj.entity;

import java.sql.Timestamp;

public class Mzyq {

	private int id;
	private String tn;
	private double sdjfrl;
	private double sdjql;
	private double sdjqsf;
	private double sdjhf;
	private double kgjsf;
	private double kgjql;
	private String kgjhff;
	private String gjgwfrl;
	private String gjql;
	private double gjwhdhff;
	private double ld;
	private double hrd;
	private double hskmxs;
	private String bz;
	private double sdjhffstart;
	private double sdjhffend;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTn() {
		return tn;
	}
	public void setTn(String tn) {
		this.tn = tn;
	}
	public double getSdjfrl() {
		return sdjfrl;
	}
	public void setSdjfrl(double sdjfrl) {
		this.sdjfrl = sdjfrl;
	}
	public double getSdjql() {
		return sdjql;
	}
	public void setSdjql(double sdjql) {
		this.sdjql = sdjql;
	}
	public double getSdjqsf() {
		return sdjqsf;
	}
	public void setSdjqsf(double sdjqsf) {
		this.sdjqsf = sdjqsf;
	}
	public double getSdjhf() {
		return sdjhf;
	}
	public void setSdjhf(double sdjhf) {
		this.sdjhf = sdjhf;
	}
	public double getKgjsf() {
		return kgjsf;
	}
	public void setKgjsf(double kgjsf) {
		this.kgjsf = kgjsf;
	}
	public double getKgjql() {
		return kgjql;
	}
	public void setKgjql(double kgjql) {
		this.kgjql = kgjql;
	}
	public String getKgjhff() {
		return kgjhff;
	}
	public void setKgjhff(String kgjhff) {
		this.kgjhff = kgjhff;
	}
	public String getGjgwfrl() {
		return gjgwfrl;
	}
	public void setGjgwfrl(String gjgwfrl) {
		this.gjgwfrl = gjgwfrl;
	}
	public String getGjql() {
		return gjql;
	}
	public void setGjql(String gjql) {
		this.gjql = gjql;
	}
	public double getGjwhdhff() {
		return gjwhdhff;
	}
	public void setGjwhdhff(double gjwhdhff) {
		this.gjwhdhff = gjwhdhff;
	}
	public double getLd() {
		return ld;
	}
	public void setLd(double ld) {
		this.ld = ld;
	}
	public double getHrd() {
		return hrd;
	}
	public void setHrd(double hrd) {
		this.hrd = hrd;
	}
	public double getHskmxs() {
		return hskmxs;
	}
	public void setHskmxs(double hskmxs) {
		this.hskmxs = hskmxs;
	}
	public String getBz() {
		return bz;
	}
	public void setBz(String bz) {
		this.bz = bz;
	}
	public double getSdjhffstart() {
		return sdjhffstart;
	}
	public void setSdjhffstart(double sdjhffstart) {
		this.sdjhffstart = sdjhffstart;
	}
	public double getSdjhffend() {
		return sdjhffend;
	}
	public void setSdjhffend(double sdjhffend) {
		this.sdjhffend = sdjhffend;
	}
}
