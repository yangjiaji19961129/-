package com.fengwuj.Dao;

import java.sql.Connection;
import java.util.List;

import com.fengwuj.entity.User;

public interface Dao {
	
	public User selectUser(String name);

	public int updateUser(User user);
	
	public int deleteUser(String username);
	
	public int updateUserPassword(String username,String newpassword);
	
}
